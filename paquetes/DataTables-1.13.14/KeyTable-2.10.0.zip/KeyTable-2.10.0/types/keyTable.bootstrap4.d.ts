
import DataTable from 'datatables.net-keytable';

export default DataTable;
export * from 'datatables.net-keytable';
